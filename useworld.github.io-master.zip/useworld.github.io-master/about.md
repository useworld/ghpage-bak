---
layout: page
title: About
permalink: /about/
---

Name : 김세용

Blog : [이것저것 다하는 블로그](https://shocora.blog.me)

E-Mail : <useworld@daum.net>

Github : [Useworld](https://github.com/useworld/useworld.github.io)

